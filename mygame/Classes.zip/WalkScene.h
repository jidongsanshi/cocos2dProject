#pragma once
#pragma once
#ifndef _WALK_SCENE_H__
#define __WALK_SCENE_H__

#include "cocos2d.h"
using namespace std;
using namespace cocos2d;
using namespace cocos2d::ui;

class CWalkScene : public cocos2d::Layer
{
public:
	// there's no 'id' in cpp, so we recommend returning the class instance pointer
	static cocos2d::Scene* createScene();

	// Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
	virtual bool init();

	// implement the "static create()" method manually
	//void onClick_package(Ref *pSender);
	CREATE_FUNC(CWalkScene);
	static bool createAnimation(string name, int num, float dt, string tag);
	void PressMove(float delta) ;
	void KeyPressMove(EventKeyboard::KeyCode keyCode);
	void KeyPressAni(EventKeyboard::KeyCode keyCode);
	void update(float delta) override;
private:
	Sprite *p_protagonist;
	std::map<cocos2d::EventKeyboard::KeyCode, bool> keys;
	//Animate *ate;
	//MoveBy *mb;
	//Spawn *sp;
};

#endif // __WALK_SCENE_H__
