#include "WalkScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;

using namespace cocostudio::timeline;

Scene* CWalkScene::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = CWalkScene::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool CWalkScene::init()
{

	if (!Layer::init())
	{
		return false;
	}

	auto rootNode = CSLoader::createNode("WalkScene.csb");
	addChild(rootNode);
	//����plist�ļ�
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("protagonist.plist", "protagonist.png");

	//���ض�������
	CWalkScene::createAnimation("protagonist_down", 3, 0.05f, "down");
	CWalkScene::createAnimation("protagonist_up", 3, 0.05f, "up");
	CWalkScene::createAnimation("protagonist_left", 3, 0.05f, "left");
	CWalkScene::createAnimation("protagonist_right", 3, 0.05f, "right");

	//��ʼ������
	p_protagonist = Sprite::createWithSpriteFrameName("protagonist_up0.png");
	p_protagonist->setPosition(Vec2(200, 200));
	this->addChild(p_protagonist);

	//��ť
	//Button *btn_package = static_cast<Button *>(rootNode->getChildByName("package"));
	//btn_package->addClickEventListener(CC_CALLBACK_1(CWalkScene::onClick_package, this));
	
	//���̼���
	auto listener = EventListenerKeyboard::create();
	listener->onKeyPressed = [=](EventKeyboard::KeyCode keyCode, Event *event) {
		log("key pressed");
		keys[keyCode] = true;
	};
	listener->onKeyReleased = [=](EventKeyboard::KeyCode keyCode, Event *event) {
		log("key released");
		keys[keyCode] = false;
	};
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
	//Spawn *sp = Spawn::create(ate, mb, NULL);
	this->schedule(schedule_selector(CWalkScene::PressMove), 0.2f);
	this->scheduleUpdate();
	return true;
}
bool CWalkScene::createAnimation(string name, int num, float dt, string tag) {
	//���ؾ���֡
	SpriteFrame* frame = NULL;
	Vector<SpriteFrame*> animFrames;
	for (int i = 0;i <= num;i++) {
		string str = StringUtils::format("%s%d.png", name.c_str(), i);
		auto frame = SpriteFrameCache::getInstance()->getSpriteFrameByName(str);
		animFrames.pushBack(frame);
	}
	//��������
	Animation *amt = Animation::createWithSpriteFrames(animFrames, dt);
	//�Ѷ������뻺��
	AnimationCache::getInstance()->addAnimation(amt, tag);
	return true;
}
void CWalkScene::update(float delta) {
	auto up = EventKeyboard::KeyCode::KEY_W;
	auto down = EventKeyboard::KeyCode::KEY_S;
	auto left = EventKeyboard::KeyCode::KEY_A;
	auto right = EventKeyboard::KeyCode::KEY_D;
	if (keys[up]) {
		KeyPressMove(up);
	}
	if (keys[down]) {
		KeyPressMove(down);
	}
	if (keys[left]) {
		KeyPressMove(left);
	}
	if (keys[right]) {
		KeyPressMove(right);
	}
}



void CWalkScene::PressMove(float delta) {
	auto up = EventKeyboard::KeyCode::KEY_W;
	auto down = EventKeyboard::KeyCode::KEY_S;
	auto left = EventKeyboard::KeyCode::KEY_A;
	auto right = EventKeyboard::KeyCode::KEY_D;
	if (keys[up]) {
		KeyPressAni(up);
	}
	if (keys[down]) {
		KeyPressAni(down);
	}
	if (keys[left]) {
		KeyPressAni(left);
	}
	if (keys[right]) {
		KeyPressAni(right);
	}
}
	
void CWalkScene::KeyPressMove(EventKeyboard::KeyCode keyCode) {
	int X = 0;int Y = 0;string tag;
	switch (keyCode)
	{
	case(EventKeyboard::KeyCode::KEY_W):
		Y = 2;
		tag = "up";
		break;
	case(EventKeyboard::KeyCode::KEY_S):
		Y = -2;
		tag = "down";
		break;
	case(EventKeyboard::KeyCode::KEY_A):
		X = -2;
		tag = "left";
		break;
	case(EventKeyboard::KeyCode::KEY_D):
		X = 2;
		tag = "right";
		break;
	default:
	break;
	}
	MoveBy *mb = MoveBy::create(0.4f, Vec2(X, Y));
	p_protagonist->runAction(mb);
}
void CWalkScene::KeyPressAni(EventKeyboard::KeyCode keyCode) {
	string tag;
	switch (keyCode)
	{
	case(EventKeyboard::KeyCode::KEY_W):
		tag = "up";
		break;
	case(EventKeyboard::KeyCode::KEY_S):
		tag = "down";
		break;
	case(EventKeyboard::KeyCode::KEY_A):
		tag = "left";
		break;
	case(EventKeyboard::KeyCode::KEY_D):
		tag = "right";
		break;
	default:
		break;
	}
	Animate *ate = Animate::create(AnimationCache::getInstance()->getAnimation(tag));
	p_protagonist->runAction(ate);
}

